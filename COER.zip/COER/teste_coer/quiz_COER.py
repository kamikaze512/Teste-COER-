import tkinter as tk
from tkinter import ttk
import random
import os

import pygame  # Importa a biblioteca pygame

# Inicializa o pygame
pygame.mixer.init()

# Carrega os sons
correct_sound = pygame.mixer.Sound("/Users/macbookpro/Desktop/COER/teste_coer/Right answer.MP3")  # Som para resposta correta
incorrect_sound = pygame.mixer.Sound("/Users/macbookpro/Desktop/COER/teste_coer/wrong answer.MP3")  # Som para resposta incorreta

# Função para ler perguntas de um arquivo
def load_questions(filename):
    questions = []
    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split(';')
            if len(parts) < 3:  # Verifica se há perguntas e respostas suficientes
                continue
            question = {
                "question": parts[0],
                "options": parts[1:-1],
                "answer": parts[-1]
            }
            questions.append(question)
    return questions

# Função para iniciar o quiz
def start_quiz():
    global current_question_index, score, quiz_data
    selected_file = combo_box.get()
    quiz_data = load_questions(selected_file)
    
    if not quiz_data:
        result_label.config(text="Nenhuma pergunta carregada. Selecione um arquivo válido.")
        return

    current_question_index = 0
    score = 0
    random.shuffle(quiz_data)
    show_question()

# Função para mostrar a pergunta atual
def show_question():
    global current_question_index
    if current_question_index < len(quiz_data):
        question_data = quiz_data[current_question_index]
        question_label.config(text=question_data["question"], fg="#FF7518", font=("Arial", 18, "bold"))
        question_label.config(wraplength=700)  # Ajusta o comprimento da quebra de linha
        
        # Atualiza os botões de opção
        for i, option in enumerate(question_data["options"]):
            option_buttons[i].config(text=option, state=tk.NORMAL, wraplength=920)  # Habilita o botão e define wraplength
        for j in range(len(question_data["options"]), len(option_buttons)):
            option_buttons[j].config(text="", state=tk.DISABLED)  # Desabilita botões extras
        
        result_label.config(text="")
    else:
        show_result()

# Função para verificar a resposta
def check_answer(selected_option):
    global score, current_question_index
    if selected_option == quiz_data[current_question_index]["answer"]:
        score += 1
        correct_sound.play()  # Toca o som de resposta correta
    else:
        incorrect_sound.play()  # Toca o som de resposta incorreta
    current_question_index += 1
    print(f"Current Question Index: {current_question_index}")  # Debugging
    show_question()

# Função para mostrar o resultado final
def show_result():
    percentage = (score / len(quiz_data)) * 100
    result_label.config(text=f"Você acertou {percentage:.2f}%.")
    if percentage > 70:
        result_label.config(text=f"Parabéns! Você acertou {percentage:.2f}%.")
        os.system('afplay /System/Library/Sounds/Glass.aiff')  # Toca um som

# Configuração da interface gráfica
root = tk.Tk()
root.title("Teste de Avaliação (COER) CLASSE C")
root.geometry("1050x600")

# Tela inicial
welcome_label2 = tk.Label(root, text="TESTE DE AVALIAÇÃO", fg="red", font=("Arial black", 44))
welcome_label2.pack(pady=20)

# ComboBox para selecionar o arquivo
file_options = ['LEGISLAÇÃO DE TELECOMUNICAÇÕES.txt', 'TÉCNICA E ÉTICA OPERACIONAL.txt']  # Adicione os arquivos disponíveis aqui
combo_box = ttk.Combobox(root, values=file_options, width=50)
combo_box.set("Selecione um arquivo")  # Texto padrão
combo_box.pack(pady=10)

start_button = tk.Button(root, text="Pressione Enter para iniciar o teste", command=start_quiz)
start_button.pack(pady=20)

# Pergunta e opções
question_label = tk.Label(root, text="", font=("Arial", 18))
question_label.pack(pady=10)

option_buttons = []
for i in range(5):  # Supondo que haja até 5 opções
    button = tk.Button(root, text="", command=lambda opt=i: check_answer(chr(97 + opt)))  # 'a' é 97
    button.pack(pady=5)
    option_buttons.append(button)

result_label = tk.Label(root, text="", font=("Arial", 12))
result_label.pack(pady=20)

# Carregar perguntas
quiz_data = load_questions('LEGISLAÇÃO DE TELECOMUNICAÇÕES.txt')

# Verificação de perguntas carreg
# Verificação de perguntas carregadas
print(f"Total de perguntas carregadas: {len(quiz_data)}")  # Debugging

# Iniciar a interface
root.mainloop()